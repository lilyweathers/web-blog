Description:  
A simple blog for posting and commenting posts with a like and delete button. Data is saved on file (db.json). ◦ Built with Node + vanilla JS.

Instructions:  
npm init -y  
node server.js  
visit localhost:3000  
  
![alt text](/screenshot.jpg)
